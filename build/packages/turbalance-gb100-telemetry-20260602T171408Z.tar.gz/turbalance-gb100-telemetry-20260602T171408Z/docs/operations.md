# Operations

This repo now includes lightweight operations templates for pilots that run the optional backend ingestion service in Kubernetes or a similar managed environment.

## Backend Deployment

Reference manifests:

```text
ops/kubernetes/ingestion-configmap.yaml
ops/kubernetes/ingestion-secret.example.yaml
ops/kubernetes/ingestion-serviceaccount.yaml
ops/kubernetes/ingestion-deployment.yaml
```

The deployment uses `TURBALANCE_STORAGE_MODE=managed-postgres-s3`, file-mounted secrets, S3-compatible object storage, and managed Postgres control/audit state. It does not mount local PVCs for ingestion state.

Generate the provider-specific pilot config from explicit provider-approved values before rendering or building anything:

```sh
node scripts/generate-provider-pilot-config.js \
  --out build/provider-a/pilot-provider.json \
  --namespace turbalance-provider-a \
  --release-name turbalance-provider-a \
  --image registry.provider.internal/ai-ops/turbalance-ingestion:2026.06 \
  --secret-provider aws \
  --secret-store-name turbalance-provider-a-secrets \
  --service-account-role-arn arn:aws:iam::210987654321:role/turbalance-provider-a-ingestion \
  --object-bucket turbalance-provider-a-ingestion \
  --object-prefix pilot/provider-a \
  --postgres-secret-name turbalance/provider-a/postgres-url \
  --tenant-tokens-secret-name turbalance/provider-a/tenant-tokens \
  --upload-secret-name turbalance/provider-a/upload-secret \
  --jwt-secret-name turbalance/provider-a/jwt-secret \
  --exporter-token-secret-name turbalance/provider-a/exporter-token \
  --ingest-tenant provider-a
```

The generator refuses placeholder registries, account IDs, secret names, and `latest` image tags. For GCP use `--gcp-service-account`, `--gcp-project-id`, `--gcp-cluster-location`, and `--gcp-cluster-name`; for Azure use `--azure-client-id`, `--azure-vault-url`, and `--azure-tenant-id`.

Render provider-specific names, image, object bucket, Postgres secret, and ExternalSecret bindings from the generated config:

```sh
node scripts/render-managed-kubernetes.js \
  --config build/provider-a/pilot-provider.json \
  --out build/turbalance-managed-kubernetes.yaml
```

Build and publish the provider-approved ingestion image referenced by the same config:

```sh
node scripts/build-publish-ingestion-image.js \
  --config build/provider-a/pilot-provider.json \
  --push
```

Run without `--push` or with `--dry-run` to print the Docker commands for approval review.

For a single auditable go-live pass, run:

```sh
node scripts/run-provider-go-live-gates.js \
  --config build/provider-a/pilot-provider.json \
  --source-contracts ops/source-contracts.example.json \
  --source-approvals ops/source-approvals.example.json \
  --iterations 3 \
  --out-dir build/provider-go-live
```

The gate runs provider readiness checks, image build/publish dry-run unless `--push-image` is provided, manifest rendering, source-contract validation, burn-in, and writes JSON plus Markdown evidence reports.

To validate configuration without executing source collection:

```sh
node scripts/validate-provider-readiness.js \
  --config build/provider-a/pilot-provider.json \
  --source-contracts ops/source-contracts.example.json \
  --source-approvals ops/source-approvals.example.json
```

## Retention Job

Use `scripts/run-retention-job.js` for cron, Kubernetes CronJob, or provider-managed scheduled task wiring:

```sh
TURBALANCE_DATA_DIR=".turbalance-data" \
TURBALANCE_RETENTION_DAYS=30 \
node scripts/run-retention-job.js --json
```

Kubernetes template:

```text
ops/kubernetes/ingestion-retention-cronjob.yaml
```

The template assumes a container image containing this repo and a persistent volume mounted at `/app/.turbalance-data`.

## Provider Export Job

Use `scripts/run-provider-pilot-export-job.js` when source-system owners provide approved exports on disk or through mounted files:

```sh
node scripts/run-provider-pilot-export-job.js \
  --input-dir fixtures/provider-pilot-export-inputs \
  --out provider-pilot-bundle.json
```

Kubernetes template:

```text
ops/kubernetes/provider-export-cronjob.yaml
```

The CronJob expects source exports to be mounted at `/var/run/turbalance-provider-exports` and posts the generated source bundle to the ingestion API.

When Prometheus access is approved, stage live Prometheus/DCGM exports before the provider bundle job:

```sh
TURBALANCE_PROMETHEUS_BEARER_TOKEN="$PROMETHEUS_TOKEN" \
node scripts/fetch-prometheus-source-export.js \
  --url https://prometheus.provider.example \
  --run-id provider-run-9001 \
  --queries-file fixtures/prometheus-collector-queries.json \
  --out-dir /var/run/turbalance-provider-exports
```

This writes `prometheus.json` and `dcgm.json` in the same shape expected by `scripts/build-provider-pilot-bundle.js`.

## Tenant Bootstrap

Use `scripts/provision-tenant.js` with an admin token to create a pilot tenant and issue the provider export token:

```sh
node scripts/provision-tenant.js \
  --url https://ingestion.example.com \
  --admin-token "$TURBALANCE_ADMIN_TOKEN" \
  --tenant provider-a \
  --display-name "Provider A" \
  --role ingest \
  --subject provider-exporter
```

Store the returned token in the provider's secret manager and mount it into `ops/kubernetes/provider-export-cronjob.yaml` through the `exporter-token` secret key. The CLI is intentionally small; production onboarding should bind it to the provider IAM, ticketing, approval, and audit workflow.

For customer onboarding plus secret-manager binding output:

```sh
node scripts/provision-customer-iam.js \
  --url https://ingestion.example.com \
  --admin-token "$TURBALANCE_ADMIN_TOKEN" \
  --tenant provider-a \
  --display-name "Provider A" \
  --provider aws \
  --secret-name turbalance/provider-a/exporter-token
```

Use `--apply-secrets` only from an approved provider automation context with the cloud CLI already authenticated.

The rendered manifests include a provider `ClusterSecretStore`, `ExternalSecret`, and service-account IAM annotations when configured in `ops/pilot-provider.config.example.json`.

## Metrics

The ingestion backend exposes Prometheus text metrics at `/metrics` for authenticated `viewer`, `operator`, or `admin` callers.

Kubernetes/Prometheus templates:

```text
ops/kubernetes/ingestion-service-monitor.yaml
ops/kubernetes/ingestion-prometheus-rules.yaml
```

The rules cover ingestion rejects, authentication failure spikes, JWKS fetch failures, and retention staleness.

## OIDC/JWKS

For OIDC discovery, set:

```sh
TURBALANCE_OIDC_DISCOVERY_URL="https://issuer.example.com/.well-known/openid-configuration"
TURBALANCE_JWT_AUDIENCE="turbalance-ingestion"
TURBALANCE_JWT_TENANT_CLAIM="customer_tenant"
TURBALANCE_JWT_ROLE_CLAIM="groups"
TURBALANCE_JWT_TENANT_MAP="external-customer-a:tenant-a"
TURBALANCE_JWT_ROLE_MAP="security-reader:viewer,platform-operator:operator"
```

The backend caches discovery and JWKS responses and exposes cache/fetch counters through `/metrics`.

## Source Collectors

Use `scripts/fetch-source-system-export.js` when source owners approve read-only HTTP exports:

```sh
node scripts/fetch-source-system-export.js \
  --system kubernetes \
  --url https://source-gateway.example/kubernetes/jobs \
  --out-dir /var/run/turbalance-provider-exports
```

Supported systems are `kubernetes`, `scheduler-admission`, `grafana`, `billing-slo`, `ebpf`, `nccl`, and `opportunities`. Prometheus/DCGM collection remains in `scripts/fetch-prometheus-source-export.js` because it uses Prometheus query semantics.

For the SPARK1 single-node Kubernetes demo, use the local `kubectl` plus Prometheus collector instead of a source-owner HTTP gateway:

```sh
kubectl apply -f ops/kubernetes/spark1-gpu-demo-job.yaml

node scripts/collect-spark1-kubernetes-demo.js \
  --run-id spark1-k8s-demo-001 \
  --namespace turbalance-demo \
  --prometheus-url http://127.0.0.1:9090 \
  --out build/demo/spark1-k8s-bundle.json
```

That bundle includes `sources.kubernetes`, `sources.scheduler`, and, when reachable, `sources.prometheus` and `sources.dcgm`. Use it only for observed SPARK1 lab evidence; keep provider queue, billing, topology, and SLO claims tied to provider-approved exports.

To enable and verify Kafka on SPARK1's lab `k3s` cluster, run the broker manifest plus smoke-check helper:

```sh
node scripts/check-spark1-kafka.js
kubectl -n turbalance-demo get pods,svc -l turba.ai/demo=spark1-kafka
kubectl -n turbalance-demo logs job/spark1-kafka-smoke
```

The helper applies `ops/kubernetes/spark1-kafka.yaml`, waits for `deployment/spark1-kafka`, recreates the smoke Job from `ops/kubernetes/spark1-kafka-smoke-job.yaml`, and fails unless a produced JSON message is consumed back from Kafka. The cluster bootstrap address is `spark1-kafka.turbalance-demo.svc.cluster.local:9092`; the SPARK1 lab NodePort address is `192.168.10.20:30992`.

Validate all approved endpoint/query contracts before enabling scheduled jobs:

```sh
node scripts/validate-source-contracts.js \
  --config ops/source-contracts.example.json \
  --out-dir build/provider-source-contracts

node scripts/validate-source-approvals.js \
  --contracts ops/source-contracts.example.json \
  --approvals ops/source-approvals.example.json \
  --out build/provider-source-approvals.json
```

Use `ops/source-contracts.example.json` and `ops/source-approvals.example.json` as provider replacement templates. The approval manifest records owner, approver, ticket, scope, expiry, URL, and Prometheus query-file signoff for each source lane. Use `ops/source-contracts.sandbox.json` and `ops/source-approvals.sandbox.json` only with a local mock source gateway on `127.0.0.1:8891` when exercising the SSH sandbox gate.

For local and SSH sandbox runs, `scripts/run-sandbox-source-gateway.js` serves the provider pilot fixtures through the same HTTP paths expected by `ops/source-contracts.sandbox.json`.

## Pilot Burn-In

Run a burn-in loop against staged source exports or validated source contracts:

```sh
node scripts/run-live-pilot-burn-in.js \
  --contracts ops/source-contracts.example.json \
  --iterations 3 \
  --ingest-url https://ingestion.example.com/v1/ingestion \
  --token "$TURBALANCE_INGEST_TOKEN" \
  --tenant provider-a \
  --out-dir build/provider-burn-in
```

Treat this as the final staging gate before customer-facing use: every iteration must build a valid source bundle, optionally ingest successfully, and leave a retained bundle artifact for review.

## Visual QA

`.github/workflows/visual-qa.yml` installs Playwright and Chromium, runs `scripts/run-screenshot-qa.js` with `TURBALANCE_SCREENSHOT_QA_REQUIRED=1`, and uploads desktop/mobile screenshots from `build/qa/`.
